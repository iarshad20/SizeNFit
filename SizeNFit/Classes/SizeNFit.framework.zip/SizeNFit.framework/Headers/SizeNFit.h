//
//  SizeNFit.h
//  SizeNFit
//
//  Created by Sandy on 27/01/19.
//  Copyright © 2019 Sandy. All rights reserved.
//

#import <UIKit/UIKit.h>

//! Project version number for SizeNFit.
FOUNDATION_EXPORT double SizeNFitVersionNumber;

//! Project version string for SizeNFit.
FOUNDATION_EXPORT const unsigned char SizeNFitVersionString[];

// In this header, you should import all the public headers of your framework using statements like #import <SizeNFit/PublicHeader.h>


